using namespace vex;

extern brain Brain;

// VEXcode devices
extern controller Controller1;
extern drivetrain Drivetrain;
extern motor_group Flywheel;
extern motor indexer;
extern motor intake_roller;
extern digital_out expansion1;
extern digital_out expansion2;
extern digital_out expansion3;
extern digital_out expansion4;
extern competition Competition;


/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );